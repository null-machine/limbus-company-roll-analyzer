Sinner Ultimate Scientific Analysis Model Of Generally Unknown Strategies
- Generates charts of skill clash ranges.
- Enemy offense level is assumed to be 30.
- Y-axis represents the chance of winning a single coin clash that has a set power.
- X-axis represents the power of the enemy single coin skill that is being clashed.
- Cyan, yellow and magenta lines are associated a chance of 0.7, 0.5 and 0.3 of rolling heads respectively.
- An additional chart will be generated for sinners reliant on ego passives, chain passives or conditionals.